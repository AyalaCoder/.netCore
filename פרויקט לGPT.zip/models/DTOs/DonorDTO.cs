﻿namespace final_project.models.DTOs
{
    public class DonorDTO
    {
        public int Id { get; set; }
        public required string Name {  get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }

    }
}
