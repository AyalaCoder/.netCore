﻿namespace final_project.models
{
    public class Category
    {
        public int Id { get; set; }
        public required string Name { get; set; }
    }
}
