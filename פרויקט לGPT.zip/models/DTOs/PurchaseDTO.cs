﻿namespace final_project.models.DTOs
{
    public class PurchaseDTO
    {
        public int GiftId { get; set; }
        public int Quantity { get; set; }
    }
}
